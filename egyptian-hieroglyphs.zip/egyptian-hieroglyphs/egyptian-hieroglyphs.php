<?php
/**
 * Egyptian Hieroglyphs (MdC)
 *
 * @package   EgyptianHieroglyphs
 * @author    ftorres.es
 * @license   GPL-2.0-or-later
 * @link      https://www.ftorres.es
 *
 * @wordpress-plugin
 * Plugin Name:       Egyptian Hieroglyphs (MdC)
 * Plugin URI:        https://www.ftorres.es/miscelanea/jeroglificos-egipcios-prueba-del-plugin-mdc/
 * Description:       Renderiza jeroglíficos egipcios desde transliteración en notación Manuel de Codage (MdC) como SVG, mediante HieroJax y la fuente NewGardiner. Incluye un bloque de Gutenberg y un shortcode.
 * Version:           1.5.8
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            ftorres.es
 * Author URI:        https://www.ftorres.es
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       egyptian-hieroglyphs
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'FT_HIERO_VERSION', '1.5.8' );
define( 'FT_HIERO_PLUGIN_FILE', __FILE__ );
define( 'FT_HIERO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'FT_HIERO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once FT_HIERO_PLUGIN_DIR . 'includes/class-assets.php';
require_once FT_HIERO_PLUGIN_DIR . 'includes/class-admin-tool.php';
require_once FT_HIERO_PLUGIN_DIR . 'includes/class-settings.php';

/**
 * Registra scripts/estilos del plugin (handles) en init.
 */
function ft_hiero_register_assets() {
	EgyptianHieroglyphs\Assets::register();
}
add_action( 'init', 'ft_hiero_register_assets' );

/**
 * Carga el dominio de traducción.
 */
function ft_hiero_load_textdomain() {
	load_plugin_textdomain( 'egyptian-hieroglyphs', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'ft_hiero_load_textdomain' );

/**
 * Registra el bloque de Gutenberg.
 */
function ft_hiero_register_block() {
	$block_json = FT_HIERO_PLUGIN_DIR . 'build/block.json';
	if ( file_exists( $block_json ) ) {
		register_block_type( $block_json );
	}
}
add_action( 'init', 'ft_hiero_register_block' );

/**
 * Carga los assets del editor (conversor MdC + runtime hierojax + bloque).
 */
function ft_hiero_enqueue_editor_assets() {
	EgyptianHieroglyphs\Assets::enqueue_editor();
}
add_action( 'enqueue_block_editor_assets', 'ft_hiero_enqueue_editor_assets' );

/**
 * Encola los assets del frontend solo cuando el bloque aparece en el contenido.
 *
 * @param string $block_content Contenido renderizado del bloque.
 * @param array  $block         Datos del bloque.
 * @return string Contenido sin modificar.
 */
function ft_hiero_maybe_enqueue_frontend( $block_content, $block ) {
	if ( isset( $block['blockName'] ) && 'egyptian-hieroglyphs/hiero' === $block['blockName'] ) {
		EgyptianHieroglyphs\Assets::enqueue_frontend();
	}
	return $block_content;
}
add_filter( 'render_block', 'ft_hiero_maybe_enqueue_frontend', 10, 2 );

/**
 * Encola los assets del frontend cuando el contenido de la entrada contiene
 * jeroglíficos aunque no usen el bloque (p. ej. HTML con spans .hierojax,
 * shortcode [hiero]).
 */
function ft_hiero_maybe_enqueue_by_content() {
	if ( ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( ! $post ) {
		return;
	}
	$content = (string) $post->post_content;

	// ¿Hay shortcode [hiero] con transliteración MdC? El shortcode convierte
	// el MdC en el cliente, así que necesita mdcconversion.js. Se detecta
	// mirando SOLO el interior de los tags [hiero]...[/hiero] (no todo el
	// post, que puede contener Unicode jeroglífico en otras partes).
	$needs_mdc = false;
	if ( preg_match_all( '/\[hiero(?:\s[^\]]*)?\](.*?)\[\/hiero\]/s', $content, $matches ) ) {
		foreach ( $matches[1] as $inner ) {
			if ( ! preg_match( '/[\x{13000}-\x{134FF}]/u', (string) $inner ) ) {
				$needs_mdc = true;
				break;
			}
		}
	}

	if ( $needs_mdc || false !== strpos( $content, 'hierojax' ) || false !== strpos( $content, 'data-mdc' ) ) {
		EgyptianHieroglyphs\Assets::enqueue_frontend( $needs_mdc );
	}
}
add_action( 'wp_enqueue_scripts', 'ft_hiero_maybe_enqueue_by_content', 20 );

/**
 * Registra el shortcode [hiero].
 */
function ft_hiero_register_shortcode() {
	add_shortcode( 'hiero', array( 'EgyptianHieroglyphs\\Assets', 'render_shortcode' ) );
}
add_action( 'init', 'ft_hiero_register_shortcode' );

/**
 * Activa el conversor MdC (página oculta, sin ítem en el menú Herramientas).
 */
EgyptianHieroglyphs\AdminTool::init();

/**
 * Activa la página de ajustes (tamaño y color por defecto).
 */
EgyptianHieroglyphs\Settings::init();

/**
 * Añade enlaces de acción en la lista de plugins:
 * "Configuración" (ajustes del plugin) y "Página web" (artículo del plugin).
 *
 * @param array $links Enlaces por defecto.
 * @return array
 */
function ft_hiero_plugin_action_links( $links ) {
	$settings = sprintf(
		'<a href="%s">%s</a>',
		esc_url( admin_url( 'options-general.php?page=ftorres-hiero-settings' ) ),
		esc_html__( 'Configuración', 'egyptian-hieroglyphs' )
	);
	$website  = sprintf(
		'<a href="%s" target="_blank" rel="noopener">%s</a>',
		esc_url( 'https://www.ftorres.es/miscelanea/jeroglificos-egipcios-prueba-del-plugin-mdc/' ),
		esc_html__( 'Página web', 'egyptian-hieroglyphs' )
	);

	array_unshift( $links, $settings );
	$links[] = $website;

	return $links;
}
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	'ft_hiero_plugin_action_links'
);
